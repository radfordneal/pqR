#include <R.h>
#include <R_ext/QuartzDevice.h>

QuartzDesc_t QuartzBitmap_DeviceCreate(void *dd, QuartzFunctions_t *fn, QuartzParameters_t *par);

