#  File src/library/base/R/ifelse.R
#  Part of the R package, http://www.R-project.org
#  Modifications for pqR Copyright (c) 2013 Radford M. Neal.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  A copy of the GNU General Public License is available at
#  http://www.r-project.org/Licenses/

ifelse <-
    function (test, yes, no)
{
    storage.mode(test) <- "logical"
    if (length(test)==1)
        return (if (is.na(test)) NA else if (test) yes else no)
    ans <- test
    na <- is.na(test)
    test.and.not.na <- test & !na
    not.test.and.not.na <- !test & !na
    if (any(test.and.not.na))
        ans [test.and.not.na] <-
           rep (yes, length.out = length(ans)) [test.and.not.na]
    if (any(not.test.and.not.na))
        ans [not.test.and.not.na] <- 
           rep(no, length.out = length(ans)) [not.test.and.not.na]
    ans[na] <- NA
    get_rm(ans)
}
